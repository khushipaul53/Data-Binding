package com.example.databinding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.example.databinding.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    var binding:ActivityMainBinding?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
         binding=DataBindingUtil.setContentView(this,R.layout.activity_main)
// adding <layout> tag in the layout
        // adding dataBinding {
        //        enabled = true
        //    } in gradle
        // by intialization Binding Class in the main activity where we have add
        // then we are good to go
        binding?.tvData!!.setText("Data Binding Success done")
    }
}